#!/usr/bin/env bash
# ===========================================================================
# provision_range.sh  —  Remove old accounts + create the Torbia roster
#                        over SSH as csra_admin, across IP ranges you enter.
#
# Prompts for:
#   * roster CSV (defaults to South)
#   * target IP ranges  (CIDR, dashed range, or single IPs)
#   * SSH password  (blank if you use key auth)
#   * sudo password (blank if csra_admin has NOPASSWD sudo)
#
# Then: DRY RUN cleanup -> you confirm -> delete old accounts -> create roster.
# csra_admin is always protected by the cleanup playbook.
#
# Run from inside the ansible-deploy folder:  ./provision_range.sh
# ===========================================================================
set -uo pipefail
# NOTE: intentionally NOT using 'set -e'. When targeting large/sparse IP ranges,
# ansible-playbook returns non-zero for unreachable (empty) IPs; with 'set -e'
# that would abort the script before the confirmation prompt. We tolerate it.
cd "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

ADMIN="csra_admin"
DEFAULT_CSV="ansible_south_torbia_users.csv"

command -v ansible-playbook >/dev/null || { echo "ERROR: ansible-playbook not found on PATH."; exit 1; }

echo "=== Torbia range provisioning (SSH as ${ADMIN}) ==="

# --- roster -----------------------------------------------------------------
read -rp "Roster CSV [${DEFAULT_CSV}]: " CSV
CSV="${CSV:-$DEFAULT_CSV}"
[[ -f "$CSV" ]] || { echo "ERROR: CSV not found: $CSV"; exit 1; }

# --- IP ranges --------------------------------------------------------------
echo
echo "Enter target IP ranges. Accepted formats (mix freely, space/comma separated):"
echo "   CIDR          10.10.20.0/24"
echo "   dashed range  10.10.20.10-50"
echo "   single host   10.10.20.5"
# Saved default ranges — press Enter at the prompt to use these.
DEFAULT_RANGES="172.24.10.150 172.24.10.180 172.24.19.0/24 172.24.18.0/24 172.24.22.0/24 172.24.21.0/24"
read -rp "IP ranges [Enter = saved default]: " RANGES
RANGES="${RANGES:-$DEFAULT_RANGES}"
[[ -n "${RANGES// }" ]] || { echo "ERROR: no ranges entered."; exit 1; }

HOSTS="$(python3 - "$RANGES" <<'PY'
import sys, re, ipaddress
out, seen = [], set()
for tok in re.split(r'[,\s]+', sys.argv[1].strip()):
    if not tok:
        continue
    try:
        if '/' in tok:
            for h in ipaddress.ip_network(tok, strict=False).hosts():
                out.append(str(h))
        elif '-' in tok:
            base, rng = tok.rsplit('.', 1)
            lo, hi = rng.split('-')
            ipaddress.ip_address(f"{base}.{lo}"); ipaddress.ip_address(f"{base}.{hi}")
            for i in range(int(lo), int(hi) + 1):
                out.append(f"{base}.{i}")
        else:
            out.append(str(ipaddress.ip_address(tok)))
    except Exception as e:
        sys.stderr.write(f"Skipping invalid token '{tok}': {e}\n")
for ip in out:
    if ip not in seen:
        seen.add(ip); print(ip)
PY
)"
[[ -n "$HOSTS" ]] || { echo "ERROR: no valid IPs parsed."; exit 1; }
COUNT="$(printf '%s\n' "$HOSTS" | grep -c .)"
echo
echo "Expanded to ${COUNT} host(s):"
printf '%s\n' "$HOSTS" | sed 's/^/   /'

# --- credentials ------------------------------------------------------------
echo
read -rsp "SSH password for ${ADMIN} (blank = key auth): " SSHPW; echo
read -rsp "sudo password for ${ADMIN} (blank = NOPASSWD):  " SUDOPW; echo
if [[ -n "$SSHPW" ]]; then
  command -v sshpass >/dev/null || { echo "ERROR: SSH password given but 'sshpass' is not installed (apt/dnf install sshpass)."; exit 1; }
fi

# --- temp inventory + vars (0600, shredded on exit) -------------------------
INV="$(mktemp)"; VARS="$(mktemp)"; chmod 600 "$INV" "$VARS"
cleanup(){ shred -u "$VARS" 2>/dev/null || rm -f "$VARS"; rm -f "$INV"; }
trap cleanup EXIT

{
  echo "[targets]"
  printf '%s\n' "$HOSTS"
  echo
  echo "[targets:vars]"
  echo "ansible_user=${ADMIN}"
  echo "ansible_connection=ssh"
  echo "ansible_host_key_checking=false"
} > "$INV"

{
  echo "admin_user: ${ADMIN}"
  [[ -n "$SSHPW"  ]] && echo "ansible_ssh_pass: \"${SSHPW}\""
  [[ -n "$SUDOPW" ]] && echo "ansible_become_pass: \"${SUDOPW}\""
} > "$VARS"

export ANSIBLE_HOST_KEY_CHECKING=False
PB_COMMON=(-i "$INV" -e @"$VARS" -e "target_group=targets")

# Reports (so you don't have to scroll the terminal) -------------------------
TS="$(date +%Y%m%d_%H%M%S)"
REPORT_DIR="reports"
mkdir -p "$REPORT_DIR"
DRY_LOG="${REPORT_DIR}/dryrun_${TS}.log"
DRY_SUMMARY="${REPORT_DIR}/dryrun_summary_${TS}.txt"

# --- 1) dry-run cleanup -----------------------------------------------------
echo
echo ">>> STEP 1/3  DRY RUN: accounts that WOULD be removed (nothing deleted yet)"
echo "    full log -> ${DRY_LOG}"
ansible-playbook "${PB_COMMON[@]}" cleanup_linux.yml 2>&1 | tee "$DRY_LOG"

# Build a clean, scrollable text summary from the dry-run output
{
  echo "==================================================================="
  echo " Torbia range DRY-RUN summary"
  echo " When      : $(date)"
  echo " Roster CSV: ${CSV}"
  echo " Targeted  : ${COUNT} host(s)"
  echo "==================================================================="
  echo
  echo "--- WOULD REMOVE (per reachable host) ---"
  grep -E "WOULD REMOVE on" "$DRY_LOG" | sed 's/^[[:space:]]*"msg": "//; s/"[[:space:]]*$//' || echo "(none captured)"
  echo
  echo "--- KEEPING (protected accounts) ---"
  grep -E "KEEPING:" "$DRY_LOG" | head -1 | sed 's/^[[:space:]]*"msg": "//; s/"[[:space:]]*$//' || echo "(none captured)"
  echo
  echo "--- Unreachable / failed hosts ---"
  grep -E "UNREACHABLE!|FAILED!|^fatal:" "$DRY_LOG" | sed 's/^/  /' || echo "  (none)"
  echo
  echo "--- PLAY RECAP ---"
  awk '/PLAY RECAP/{f=1} f' "$DRY_LOG"
} > "$DRY_SUMMARY"

echo
echo "Dry-run complete. You can open these in an editor / less:"
echo "  Summary : ${DRY_SUMMARY}   <-- read this one"
echo "  Full log: ${DRY_LOG}"
echo

read -rp "After reviewing the summary, type YES to delete and then create users: " OK
[[ "$OK" == "YES" ]] || { echo "Aborted. Nothing changed. Reports saved in ${REPORT_DIR}/"; exit 0; }

# --- 2) remove old accounts -------------------------------------------------
DEL_LOG="${REPORT_DIR}/delete_${TS}.log"
echo
echo ">>> STEP 2/3  Removing old accounts (keeping ${ADMIN})   log -> ${DEL_LOG}"
ansible-playbook "${PB_COMMON[@]}" -e confirm=yes cleanup_linux.yml 2>&1 | tee "$DEL_LOG"

# --- 3) create the roster ---------------------------------------------------
NEW_LOG="${REPORT_DIR}/create_${TS}.log"
echo
echo ">>> STEP 3/3  Creating roster from ${CSV}   log -> ${NEW_LOG}"
ansible-playbook "${PB_COMMON[@]}" -e "csv_file=${CSV}" deploy_linux.yml 2>&1 | tee "$NEW_LOG"

echo
echo "=== Done. ${COUNT} host(s) processed from ${CSV}. Reports in ${REPORT_DIR}/ ==="
