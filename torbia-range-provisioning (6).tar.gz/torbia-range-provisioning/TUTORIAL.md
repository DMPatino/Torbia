# Deploying the Torbia Exercise Users with Ansible

Step-by-step for standing up the fictional South/North Torbia user accounts on
the range from the CSV rosters. Covers **removing existing accounts first**, then
provisioning, on both Linux and the Domain Controllers.

> **Scope:** isolated training/exercise range you administer. The weak passwords
> and relaxed password policy below are deliberate and belong on a lab network
> only. Keep the password CSVs on the range — they're the answer key.

> **Assumptions for this build:** you authenticate as **`csra_admin`**
> everywhere — SSH to the Linux boxes, WinRM to the DCs (already enabled and
> already accepting `csra_admin`). No vault, no new WinRM setup.

---

## 0. Quick path (scripted, Linux over SSH)

To remove old accounts and create the roster across a set of IP ranges in one go:

```bash
./provision_range.sh
```

It prompts for the roster CSV, the target IP ranges (CIDR like `10.10.20.0/24`,
dashed like `10.10.20.10-50`, or single IPs), and `csra_admin`'s SSH/sudo
passwords (leave blank for key auth / NOPASSWD sudo). It then runs a **dry-run
cleanup**, waits for you to type `YES`, deletes the old accounts (keeping
`csra_admin`), and deploys the roster. Credentials go in a temp file that's
shredded on exit. This path covers the Linux boxes; the DC steps below are
still run with the AD playbooks.

The manual steps below do the same thing playbook-by-playbook and cover the DC.

---

## 1. What you have

| File | Purpose |
|------|---------|
| `ansible_south_torbia_users.csv` | 55 users, `department`/`title` columns |
| `ansible_north_torbia_users.csv` | 33 users, `position` column |
| `inventory.ini` | Your hosts (edit the IPs) |
| `cleanup_linux.yml` / `cleanup_windows_ad.yml` | Remove existing accounts (dry-run by default) |
| `relax_ad_password_policy.yml` | Let AD accept the weak passwords |
| `deploy_linux.yml` / `deploy_windows_ad.yml` | Create the roster |

Put the CSVs in this folder — the playbooks read them from the control node.

---

## 2. Control node prerequisites

On your Ansible control box:

```bash
python3 -m pip install --user ansible pywinrm
ansible-galaxy collection install community.general          # read_csv
ansible-galaxy collection install ansible.windows microsoft.ad   # DC plays
```

- **Linux targets:** SSH reachable, `csra_admin` can `sudo`.
- **DCs:** WinRM already up and accepting `csra_admin` (nothing to configure).

---

## 3. Authentication (no vault)

You connect as `csra_admin` and supply the password at runtime.

- **Linux (SSH):** inventory sets `ansible_user=csra_admin`. With key auth you
  only need `--ask-become-pass` for sudo (drop it if sudo is NOPASSWD). With an
  SSH password add `--ask-pass` (needs `sshpass` on the control node).
- **DCs (WinRM):** inventory sets `ansible_user=csra_admin@southtorbia.range`.
  Supply the password with `--ask-pass`. Override the domain per run for the
  north DC: `-e ansible_user=csra_admin@northtorbia.range`.

> If you run the DC plays **from the DC itself**, you can set that host to
> `ansible_connection=local` and skip WinRM entirely.

Edit `inventory.ini` with your real hostnames/IPs, then sanity-check:

```bash
ansible -i inventory.ini south_linux -m ping --ask-become-pass
ansible -i inventory.ini south_dc -m ansible.windows.win_ping --ask-pass
```

---

## 4. Remove existing accounts FIRST (keeps csra_admin)

Two-stage and deliberately cautious: **dry-run, read the list, then confirm.**

> **`csra_admin` is hard-protected.** It's baked into the protect-list in both
> cleanup playbooks (not just a flag), so it's kept on every box regardless. As
> a backstop, each run aborts and deletes nothing if `csra_admin` ever appears in
> the removal list. Confirm it shows under **KEEPING** in the dry-run first.

### Linux

Only touches human accounts (UID 1000–60000); never system accounts. Always
protects `root`, `nobody`, `csra_admin`, and the `admin_user` you pass.

```bash
# Stage 1 — DRY RUN (prints WOULD REMOVE / KEEPING, deletes nothing)
ansible-playbook -i inventory.ini cleanup_linux.yml \
    -e "target_group=south_linux" \
    -e "admin_user=csra_admin" \
    --ask-become-pass

# Stage 2 — actually delete (also removes home dirs)
ansible-playbook -i inventory.ini cleanup_linux.yml \
    -e "target_group=south_linux" \
    -e "admin_user=csra_admin" \
    -e confirm=yes \
    --ask-become-pass
```

Swap `target_group=north_linux` for the OPFOR boxes.

### Domain Controller

> **On Ansible 2.9 (the range standard), do NOT use the `*_windows_ad.yml`
> playbooks in this tutorial** — they rely on the `microsoft.ad` collection,
> which needs ansible-core 2.15+. Instead use **`provision_dc.ps1`**, run ON the
> DC. It does the whole DC job (relax policy → remove old OU users, keeping
> `csra_admin` → create the roster as domain accounts) with a dry-run and report,
> same as the Linux flow. See QUICKSTART_SOUTH.md §4. Quick version:
>
> ```bash
> scp provision_dc.ps1 ansible_south_torbia_users.csv csra_admin@172.24.18.5:C:/Users/csra_admin/
> ssh csra_admin@172.24.18.5
> ```
> ```
> cd C:\Users\csra_admin
> powershell -ExecutionPolicy Bypass -File provision_dc.ps1 -RemoveExisting            # dry run
> powershell -ExecutionPolicy Bypass -File provision_dc.ps1 -Execute -RemoveExisting   # apply
> ```
>
> The Ansible DC steps below are kept only for a control node on ansible-core 2.15+.

Scoped to an OU so you can't empty the domain. Point `search_base` at the OU to
clear. `Administrator`, `krbtgt`, and `csra_admin` are always protected.

```bash
# Stage 1 — DRY RUN
ansible-playbook -i inventory.ini cleanup_windows_ad.yml \
    -e "target_group=south_dc" \
    -e "search_base=OU=Exercise Users,DC=southtorbia,DC=range" \
    -e "admin_user=csra_admin" \
    --ask-pass

# Stage 2 — delete
ansible-playbook -i inventory.ini cleanup_windows_ad.yml \
    -e "target_group=south_dc" \
    -e "search_base=OU=Exercise Users,DC=southtorbia,DC=range" \
    -e "admin_user=csra_admin" \
    -e confirm=yes \
    --ask-pass
```

> Never set `search_base` to the domain root unless you truly mean to; the
> protect-list is your only backstop there.

---

## 5. (DC only) Relax the password policy

rockyou passwords are weak on purpose. The default domain policy requires
complexity + a 7-char minimum, so passwords like `dragon` get **rejected** and
the account lands disabled with no usable password. Relax it first:

```bash
ansible-playbook -i inventory.ini relax_ad_password_policy.yml \
    -e "target_group=south_dc" --ask-pass
```

Disables complexity, drops minimum length to 1, clears history — so every
rockyou password imports cleanly. (Linux has no such policy; no equivalent step.)

---

## 6. Deploy the roster

### Linux

Passwords are hashed to SHA-512 on the fly; the CSV holds plaintext, the box only
ever sees the hash.

```bash
ansible-playbook -i inventory.ini deploy_linux.yml \
    -e "csv_file=ansible_south_torbia_users.csv" \
    -e "target_group=south_linux" \
    --ask-become-pass
```

Each user gets a home dir, a login shell, and a per-department group.
`update_password: on_create` means re-running won't overwrite a password a
trainee changed.

### Domain Controller

```bash
ansible-playbook -i inventory.ini deploy_windows_ad.yml \
    -e "csv_file=ansible_south_torbia_users.csv" \
    -e "target_group=south_dc" \
    -e "domain_dn=DC=southtorbia,DC=range" \
    -e "upn_suffix=southtorbia.range" \
    --ask-pass
```

Accounts land under `OU=Exercise Users`, in a sub-OU per `department`, enabled,
passwords set to never expire.

**North Torbia** — repeat with the north CSV and north targets:

```bash
ansible-playbook -i inventory.ini deploy_windows_ad.yml \
    -e "csv_file=ansible_north_torbia_users.csv" \
    -e "target_group=north_dc" \
    -e "domain_dn=DC=northtorbia,DC=range" \
    -e "upn_suffix=northtorbia.range" \
    -e "ansible_user=csra_admin@northtorbia.range" \
    --ask-pass
```

(The north CSV uses a `position` column; the playbooks fall back to it, and with
no `department` column everyone lands in the base OU.)

---

## 7. Verify

```bash
# Linux
ansible -i inventory.ini south_linux -b -a "getent passwd" --ask-become-pass | grep -i torbia || true
ansible -i inventory.ini south_linux -b -a "id taehyun.kim" --ask-become-pass

# DC
ansible -i inventory.ini south_dc -m ansible.windows.win_shell \
    -a "Get-ADUser -Filter * -SearchBase 'OU=Exercise Users,DC=southtorbia,DC=range' | Select SamAccountName,Enabled" \
    --ask-pass
```

Spot-check the two forced passwords: `daeho.chun` / `dragon` and `youngjae.kil`
/ `iloveyou`.

---

## 8. Tips

- **Dry-run anything** with `--check --diff` on the deploy plays too.
- **Target one host** while testing with `--limit <host>`.
- **Idempotent:** re-running deploy is safe; it won't duplicate accounts or reset
  changed passwords.
- **Teardown after the exercise:** re-run the cleanup plays against the Exercise
  OU / the Linux boxes to reset the range.
- **Account format for the DC:** if `csra_admin@domain` doesn't auth, try
  `DOMAIN\csra_admin`.
- Keep the CSVs off the target network when the exercise isn't running.
