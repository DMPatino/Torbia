# South Torbia — Quick Deploy (from anywhere on the range)

Works from any control node that can SSH to the boxes as `csra_admin`.
Since the networks touch and `csra_admin` is on every box, any machine with the
kit + Ansible can drive it.

## 1. One-time setup on the control node
```bash
python3 -m pip install --user ansible pywinrm
ansible-galaxy collection install community.general ansible.windows microsoft.ad
# only if you use SSH *passwords* (not keys):
sudo apt install -y sshpass   # or: sudo dnf install -y sshpass
```

## 2. Get the kit
```bash
tar -xzf ansible-deploy.tar.gz
cd ansible-deploy
```

## 3. Linux boxes — remove old + create roster (one command)
```bash
./provision_range.sh
```
Answer the prompts:
- **Roster CSV:** press Enter (defaults to `ansible_south_torbia_users.csv`)
- **IP ranges:** e.g. `10.10.20.0/24  10.10.21.10-50  10.10.22.5`
- **SSH password:** blank if key auth
- **sudo password:** blank if NOPASSWD
Then read the DRY-RUN list and type **YES** to proceed. `csra_admin` is always kept.

## 4. Domain Controller — run `provision_dc.ps1` ON the DC
The AD users are **domain accounts**, created once on the DC (ATROPIA,
`172.24.18.5`). Use the PowerShell script — it runs on Ansible-2.9 setups, unlike
the `*_windows_ad.yml` playbooks (those need ansible-core 2.15+; leave them).

```bash
# a) copy the script + roster CSV to the DC (from the control node)
scp provision_dc.ps1 ansible_south_torbia_users.csv csra_admin@172.24.18.5:C:/Users/csra_admin/

# b) SSH to the DC
ssh csra_admin@172.24.18.5
```
Then on the DC:
```
cd C:\Users\csra_admin

# DRY RUN — shows WOULD REMOVE / WOULD CREATE, writes reports\dc_provision_*.txt, changes nothing
powershell -ExecutionPolicy Bypass -File provision_dc.ps1 -RemoveExisting

# EXECUTE — relax policy, remove old OU users (keeps csra_admin), create the roster
powershell -ExecutionPolicy Bypass -File provision_dc.ps1 -Execute -RemoveExisting
```
It relaxes the password policy, creates the `Exercise Users` OU, and makes each
user a domain account with a `user@atropia.internal` UPN. `csra_admin` is always
protected. Re-running updates instead of duplicating.

## 5. Verify
```
# on the DC
powershell -c "Get-ADUser -Filter * -SearchBase 'OU=Exercise Users,DC=atropia,DC=internal' | Select SamAccountName,Enabled"
```
Spot-check: `seoah.lee` = `dragon`, `eunwoo.jeong` = `iloveyou`.

---
That's it. Linux = `provision_range.sh`; DC = `provision_dc.ps1`.
