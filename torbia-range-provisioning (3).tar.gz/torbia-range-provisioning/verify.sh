#!/usr/bin/env bash
# ===========================================================================
# verify.sh  —  Check that the roster users landed on each Linux host.
#
# Reuses the saved host list from provision_range.sh (DEFAULT_RANGES), so it
# always matches what you deployed. SSHes in as csra_admin and checks whether a
# sample user exists on each box.
#
#   ./verify.sh                 # checks default sample users
#   ./verify.sh seoah.lee       # check a specific username
#   HOSTS="10.0.0.5 10.0.0.6" ./verify.sh    # override host list
# ===========================================================================
set -uo pipefail
cd "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

ADMIN="csra_admin"

# Users to check on each host (override by passing names as arguments)
if [[ $# -gt 0 ]]; then
  CHECK_USERS=("$@")
else
  CHECK_USERS=(doyoon.kim seoah.lee hajoon.park)
fi

# Host list: use $HOSTS if set, else pull DEFAULT_RANGES from provision_range.sh
if [[ -n "${HOSTS:-}" ]]; then
  IPS="$HOSTS"
else
  IPS="$(grep -E '^DEFAULT_RANGES=' provision_range.sh | sed -E 's/^DEFAULT_RANGES="(.*)"/\1/')"
fi
[[ -n "$IPS" ]] || { echo "ERROR: no hosts found (set HOSTS=... or DEFAULT_RANGES in provision_range.sh)"; exit 1; }

printf 'Verifying %d user(s) [%s] as %s\n\n' "${#CHECK_USERS[@]}" "${CHECK_USERS[*]}" "$ADMIN"

ok_hosts=0; bad_hosts=0
for ip in $IPS; do
  echo "== $ip =="
  # one SSH call per host; report each user OK/MISSING
  result="$(ssh -o ConnectTimeout=5 -o BatchMode=yes "${ADMIN}@${ip}" '
    for u in '"${CHECK_USERS[*]}"'; do
      if id "$u" >/dev/null 2>&1; then echo "  $u: OK"; else echo "  $u: MISSING"; fi
    done' 2>/dev/null)"
  if [[ -z "$result" ]]; then
    echo "  UNREACHABLE (ssh failed)"
    ((bad_hosts++))
  else
    echo "$result"
    if echo "$result" | grep -q MISSING; then ((bad_hosts++)); else ((ok_hosts++)); fi
  fi
done

echo
echo "Summary: ${ok_hosts} host(s) fully provisioned, ${bad_hosts} with missing users or unreachable."
