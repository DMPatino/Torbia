#!/usr/bin/env bash
# ===========================================================================
# provision_range.sh  —  Remove old accounts + create the Torbia roster
#                        over SSH as csra_admin, across IP ranges you enter.
#
# Prompts for:
#   * roster CSV (defaults to South)
#   * target IP ranges  (CIDR, dashed range, or single IPs)
#   * SSH password  (blank if you use key auth)
#   * sudo password (blank if csra_admin has NOPASSWD sudo)
#
# Then: DRY RUN cleanup -> you confirm -> delete old accounts -> create roster.
# csra_admin is always protected by the cleanup playbook.
#
# Run from inside the ansible-deploy folder:  ./provision_range.sh
# ===========================================================================
set -euo pipefail
cd "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

ADMIN="csra_admin"
DEFAULT_CSV="ansible_south_torbia_users.csv"

command -v ansible-playbook >/dev/null || { echo "ERROR: ansible-playbook not found on PATH."; exit 1; }

echo "=== Torbia range provisioning (SSH as ${ADMIN}) ==="

# --- roster -----------------------------------------------------------------
read -rp "Roster CSV [${DEFAULT_CSV}]: " CSV
CSV="${CSV:-$DEFAULT_CSV}"
[[ -f "$CSV" ]] || { echo "ERROR: CSV not found: $CSV"; exit 1; }

# --- IP ranges --------------------------------------------------------------
echo
echo "Enter target IP ranges. Accepted formats (mix freely, space/comma separated):"
echo "   CIDR          10.10.20.0/24"
echo "   dashed range  10.10.20.10-50"
echo "   single host   10.10.20.5"
read -rp "IP ranges: " RANGES
[[ -n "${RANGES// }" ]] || { echo "ERROR: no ranges entered."; exit 1; }

HOSTS="$(python3 - "$RANGES" <<'PY'
import sys, re, ipaddress
out, seen = [], set()
for tok in re.split(r'[,\s]+', sys.argv[1].strip()):
    if not tok:
        continue
    try:
        if '/' in tok:
            for h in ipaddress.ip_network(tok, strict=False).hosts():
                out.append(str(h))
        elif '-' in tok:
            base, rng = tok.rsplit('.', 1)
            lo, hi = rng.split('-')
            ipaddress.ip_address(f"{base}.{lo}"); ipaddress.ip_address(f"{base}.{hi}")
            for i in range(int(lo), int(hi) + 1):
                out.append(f"{base}.{i}")
        else:
            out.append(str(ipaddress.ip_address(tok)))
    except Exception as e:
        sys.stderr.write(f"Skipping invalid token '{tok}': {e}\n")
for ip in out:
    if ip not in seen:
        seen.add(ip); print(ip)
PY
)"
[[ -n "$HOSTS" ]] || { echo "ERROR: no valid IPs parsed."; exit 1; }
COUNT="$(printf '%s\n' "$HOSTS" | grep -c .)"
echo
echo "Expanded to ${COUNT} host(s):"
printf '%s\n' "$HOSTS" | sed 's/^/   /'

# --- credentials ------------------------------------------------------------
echo
read -rsp "SSH password for ${ADMIN} (blank = key auth): " SSHPW; echo
read -rsp "sudo password for ${ADMIN} (blank = NOPASSWD):  " SUDOPW; echo
if [[ -n "$SSHPW" ]]; then
  command -v sshpass >/dev/null || { echo "ERROR: SSH password given but 'sshpass' is not installed (apt/dnf install sshpass)."; exit 1; }
fi

# --- temp inventory + vars (0600, shredded on exit) -------------------------
INV="$(mktemp)"; VARS="$(mktemp)"; chmod 600 "$INV" "$VARS"
cleanup(){ shred -u "$VARS" 2>/dev/null || rm -f "$VARS"; rm -f "$INV"; }
trap cleanup EXIT

{
  echo "[targets]"
  printf '%s\n' "$HOSTS"
  echo
  echo "[targets:vars]"
  echo "ansible_user=${ADMIN}"
  echo "ansible_connection=ssh"
  echo "ansible_host_key_checking=false"
} > "$INV"

{
  echo "admin_user: ${ADMIN}"
  [[ -n "$SSHPW"  ]] && echo "ansible_ssh_pass: \"${SSHPW}\""
  [[ -n "$SUDOPW" ]] && echo "ansible_become_pass: \"${SUDOPW}\""
} > "$VARS"

export ANSIBLE_HOST_KEY_CHECKING=False
PB_COMMON=(-i "$INV" -e @"$VARS" -e "target_group=targets")

# --- 1) dry-run cleanup -----------------------------------------------------
echo
echo ">>> STEP 1/3  DRY RUN: accounts that WOULD be removed (nothing deleted yet)"
ansible-playbook "${PB_COMMON[@]}" cleanup_linux.yml

echo
read -rp "Review the WOULD REMOVE / KEEPING lists above. Type YES to delete and then create users: " OK
[[ "$OK" == "YES" ]] || { echo "Aborted. Nothing changed."; exit 0; }

# --- 2) remove old accounts -------------------------------------------------
echo
echo ">>> STEP 2/3  Removing old accounts (keeping ${ADMIN})"
ansible-playbook "${PB_COMMON[@]}" -e confirm=yes cleanup_linux.yml

# --- 3) create the roster ---------------------------------------------------
echo
echo ">>> STEP 3/3  Creating roster from ${CSV}"
ansible-playbook "${PB_COMMON[@]}" -e "csv_file=${CSV}" deploy_linux.yml

echo
echo "=== Done. ${COUNT} host(s) provisioned from ${CSV}. ==="
