<#
=============================================================================
 provision_dc.ps1  —  Create the Torbia roster as ATROPIA domain accounts.

 Run this ON the Domain Controller (172.24.18.5), where the AD module lives.
 Mirrors the Linux workflow: DRY RUN by default, writes a report, and only
 changes anything when you pass -Execute. csra_admin is always protected.

 Copy the script + roster CSV to the DC first (from the control node):
   scp provision_dc.ps1 ansible_south_torbia_users.csv csra_admin@172.24.18.5:C:/Users/csra_admin/

 Then on the DC (SSH or RDP):
   # 1) DRY RUN — shows what would happen, writes a report, changes nothing
   powershell -ExecutionPolicy Bypass -File provision_dc.ps1

   # 2) EXECUTE — relax policy, (optionally) remove old OU users, create roster
   powershell -ExecutionPolicy Bypass -File provision_dc.ps1 -Execute -RemoveExisting
=============================================================================
#>
[CmdletBinding()]
param(
  [string]$CsvPath       = ".\ansible_south_torbia_users.csv",
  [string]$OUName        = "Exercise Users",
  [string]$ProtectUser   = "csra_admin",
  [switch]$RemoveExisting,              # remove existing users in the OU first (except protected)
  [switch]$RelaxPolicy    = $true,      # relax domain password policy so weak passwords import
  [switch]$Execute                      # without this, it's a DRY RUN
)

$ErrorActionPreference = "Stop"
Import-Module ActiveDirectory

$domain   = Get-ADDomain
$domainDN = $domain.DistinguishedName
$dns      = $domain.DNSRoot
$ouPath   = "OU=$OUName,$domainDN"
$protected = @($ProtectUser, "Administrator", "krbtgt", "Guest") | ForEach-Object { $_.ToLower() }

$ts        = Get-Date -Format "yyyyMMdd_HHmmss"
$reportDir = ".\reports"
if (-not (Test-Path $reportDir)) { New-Item -ItemType Directory -Path $reportDir | Out-Null }
$report    = Join-Path $reportDir "dc_provision_$ts.txt"

function Log($msg) { $msg | Tee-Object -FilePath $report -Append }

$mode = if ($Execute) { "EXECUTE" } else { "DRY RUN" }
Log "==================================================================="
Log " Torbia DC provisioning  [$mode]"
Log " When     : $(Get-Date)"
Log " Domain   : $dns ($domainDN)"
Log " Target OU: $ouPath"
Log " CSV      : $CsvPath"
Log " Protected: $($protected -join ', ')"
Log "==================================================================="

if (-not (Test-Path $CsvPath)) { Log "ERROR: CSV not found: $CsvPath"; exit 1 }
$roster = Import-Csv $CsvPath
Log "Roster rows: $($roster.Count)"
Log ""

# --- plan: removals -------------------------------------------------------
$toRemove = @()
if ($RemoveExisting) {
  if (Get-ADOrganizationalUnit -Filter "Name -eq '$OUName'" -SearchBase $domainDN -ErrorAction SilentlyContinue) {
    $existing = Get-ADUser -Filter * -SearchBase $ouPath -ErrorAction SilentlyContinue
    $toRemove = $existing | Where-Object { $protected -notcontains $_.SamAccountName.ToLower() }
  }
  Log "--- WOULD REMOVE (existing users in OU, excluding protected) ---"
  if ($toRemove) { $toRemove | ForEach-Object { Log "  $($_.SamAccountName)" } } else { Log "  (none)" }
  Log ""
}

# --- plan: creations ------------------------------------------------------
Log "--- WOULD CREATE / UPDATE (from roster) ---"
foreach ($r in $roster) {
  $sam = $r.username
  if ($protected -contains $sam.ToLower()) { Log "  SKIP $sam (protected)"; continue }
  $exists = [bool](Get-ADUser -Filter "SamAccountName -eq '$sam'" -ErrorAction SilentlyContinue)
  $verb = if ($exists) { "update" } else { "create" }
  Log ("  {0,-16} {1,-8} {2}" -f $sam, $verb, $r.title)
}
Log ""

# --- SAFETY: never let the protected account be removed --------------------
if ($toRemove.SamAccountName -and ($toRemove.SamAccountName.ToLower() -contains $ProtectUser.ToLower())) {
  Log "ABORT: $ProtectUser is in the removal list. Nothing changed."
  exit 1
}

if (-not $Execute) {
  Log "DRY RUN complete. Review above, then re-run with -Execute to apply."
  Log "Report: $report"
  exit 0
}

# ==========================================================================
#  EXECUTE
# ==========================================================================

# 1) relax password policy so the weak rockyou passwords import
if ($RelaxPolicy) {
  Log "Relaxing default domain password policy (complexity off, min length 1)..."
  Set-ADDefaultDomainPasswordPolicy -Identity $dns -ComplexityEnabled $false `
    -MinPasswordLength 1 -MinPasswordAge "0.00:00:00" -PasswordHistoryCount 0
}

# 2) ensure the OU exists
if (-not (Get-ADOrganizationalUnit -Filter "Name -eq '$OUName'" -SearchBase $domainDN -ErrorAction SilentlyContinue)) {
  Log "Creating OU: $ouPath"
  New-ADOrganizationalUnit -Name $OUName -Path $domainDN -ProtectedFromAccidentalDeletion $false
}

# 3) remove old users (if requested)
if ($RemoveExisting -and $toRemove) {
  foreach ($u in $toRemove) {
    Log "Removing $($u.SamAccountName)"
    Remove-ADUser -Identity $u -Confirm:$false
  }
}

# 4) create / update roster users
$created = 0; $updated = 0
foreach ($r in $roster) {
  $sam = $r.username
  if ($protected -contains $sam.ToLower()) { Log "SKIP $sam (protected)"; continue }

  $pw  = ConvertTo-SecureString $r.password -AsPlainText -Force
  $upn = "$sam@$dns"
  $existing = Get-ADUser -Filter "SamAccountName -eq '$sam'" -ErrorAction SilentlyContinue

  if ($existing) {
    Set-ADAccountPassword -Identity $sam -Reset -NewPassword $pw
    Set-ADUser -Identity $sam -Enabled $true -PasswordNeverExpires $true `
      -DisplayName $r.display_name -GivenName $r.first_name -Surname $r.last_name `
      -Department $r.department -Title $r.title
    Log "updated $sam"
    $updated++
  } else {
    New-ADUser -Name $r.display_name -SamAccountName $sam -UserPrincipalName $upn `
      -GivenName $r.first_name -Surname $r.last_name -DisplayName $r.display_name `
      -Department $r.department -Title $r.title `
      -AccountPassword $pw -Enabled $true -PasswordNeverExpires $true `
      -Path $ouPath
    Log "created $sam"
    $created++
  }
}

Log ""
Log "=== Done. Created $created, updated $updated. Report: $report ==="
