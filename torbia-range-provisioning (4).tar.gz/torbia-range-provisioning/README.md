# torbia-range-provisioning

Ansible for standing up the **Torbia cyber-range** user accounts — removes the
existing accounts on each box (keeping `csra_admin`) and creates the exercise
roster from a CSV, over SSH (Linux) and WinRM (Domain Controllers).

> **Exercise/lab use only.** The rosters use deliberately weak passwords and the
> DC playbook relaxes the domain password policy so they import. Do not point
> this at production.

## ⚠️ Private repo — contains the answer key
The `ansible_*_torbia_users.csv` rosters contain **plaintext exercise passwords**
(rockyou) and **are committed** here on purpose, so one clone builds the whole
range. **Keep this repository private.** Do not mirror it to a shared/public
remote. Credentials/vault files are still excluded (see `.gitignore`).

## Reports
`provision_range.sh` writes timestamped logs to `reports/` each run (gitignored):
`dryrun_summary_<ts>.txt` (clean list of WOULD REMOVE / KEEPING), plus full logs
for the dry-run, delete, and create steps — so you can read results in an editor
instead of scrolling the terminal.

## Layout
| File | Purpose |
|------|---------|
| `provision_range.sh` | Prompted wrapper: enter IP ranges, dry-run, confirm, delete + create (Linux) |
| `verify.sh` | Post-run check: SSH to each host and confirm the roster users exist |
| `cleanup_linux.yml` | Remove old Linux accounts (keeps `csra_admin`), dry-run by default |
| `deploy_linux.yml` | Create roster on Linux |
| `cleanup_windows_ad.yml` | Remove old AD users in an OU (keeps `csra_admin`) |
| `relax_ad_password_policy.yml` | Let weak passwords import on the DC (Ansible; needs 2.15+) |
| `provision_dc.ps1` | **DC provisioning that runs on 2.9 setups** — PowerShell, runs on the DC itself (create/remove domain users, dry-run + report, csra_admin protected) |
| `deploy_windows_ad.yml` | Create roster in AD |
| `inventory.ini` | Hosts (edit for the DC; Linux IPs come from the script) |
| `TUTORIAL.md` / `QUICKSTART_SOUTH.md` | Full and quick walkthroughs |

## Quick start (Linux)
```bash
ansible-galaxy collection install community.general ansible.windows microsoft.ad
# place the roster CSV(s) in this folder (they are gitignored)
./provision_range.sh          # enter IP ranges -> dry-run -> type YES
```

## Requirements
- Ansible 2.9+ on the control node, `community.general` collection
- `csra_admin` reachable by SSH (Linux) / WinRM (DC)
- `sshpass` only if using SSH passwords instead of keys

See `TUTORIAL.md` for the DC steps and full detail.
