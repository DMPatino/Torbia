# Torbia Range Provisioning — Instructor Distribution

**Audience:** CCoE exercise instructors only.
**Purpose:** Stand up the Torbia range user accounts (remove existing accounts,
create the exercise roster) via Ansible.

## ⚠️ Handle as instructor-only / answer key
The `ansible_*_torbia_users.csv` files contain the **plaintext exercise
passwords** (intentionally weak, rockyou-sourced). This is the range answer key.
Keep this package within the instructor team — do not hand it to students or post
it where trainees can reach it.

## Status (what's tested vs. pending)
- **Linux provisioning — working.** `provision_range.sh` + `cleanup_linux.yml` +
  `deploy_linux.yml`, over SSH as `csra_admin`. Tested on the range.
- **Windows / Domain Controller — use `provision_dc.ps1`.** The Ansible
  `*_windows_ad.yml` playbooks use the `microsoft.ad` collection (needs
  ansible-core 2.15+) and will NOT run on the range's 2.9.6 node — leave them be.
  Instead use **`provision_dc.ps1`**, a self-contained PowerShell provisioner you
  run ON the DC (ATROPIA, 172.24.18.5): it relaxes the password policy, creates
  the roster as domain accounts in the "Exercise Users" OU, protects csra_admin,
  and is DRY RUN by default (add -Execute to apply). Copy it + the roster CSV to
  the DC, then:
      powershell -ExecutionPolicy Bypass -File provision_dc.ps1               # dry run
      powershell -ExecutionPolicy Bypass -File provision_dc.ps1 -Execute -RemoveExisting

## Control node requirements
- Ansible 2.9+ (range standard is 2.9.6). The Linux playbooks use only bundled
  modules (`read_csv`, `getent`, `user`) — no extra collections needed.
- `csra_admin` reachable by SSH on the targets.
- `sshpass` only if using SSH passwords instead of keys.

## Quick start (Linux)
```bash
# recreate the local tuning config (not shipped; host-specific):
cat > ansible.cfg <<'EOF'
[defaults]
forks = 100
timeout = 5
host_key_checking = False
deprecation_warnings = False
interpreter_python = auto_silent
[ssh_connection]
pipelining = True
ssh_args = -o ControlMaster=auto -o ControlPersist=60s -o ConnectTimeout=5
EOF

chmod +x provision_range.sh
./provision_range.sh      # Enter CSV -> enter/accept IP ranges -> dry-run -> type YES
```

`csra_admin` is always protected by the cleanup playbook (hard-coded, plus an
abort guard). Each run writes logs to `reports/` so you can review results in a
file instead of scrolling the terminal.

See `TUTORIAL.md` (full) and `QUICKSTART_SOUTH.md` (short) for detail.
